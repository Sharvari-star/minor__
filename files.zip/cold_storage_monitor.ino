/*
  Cold Storage Remote Monitor
  Arduino Nano + DHT22 + I2C LCD + AC sense + Relay + Buzzer + SIM800L
  - SMS alerts (temperature, humidity, power failure)
  - Live dashboard on ThingSpeak over GPRS (plain HTTP, AT commands)

  Libraries to install (Library Manager):
    - DHT sensor library (Adafruit) + Adafruit Unified Sensor
    - LiquidCrystal I2C (Frank de Brabander)
  SoftwareSerial and Wire come with the Arduino IDE.

  Wiring (Nano):
    DHT22 DATA -> D2 (10K pull-up to 5V)
    AC sense OUT -> D3
    Buzzer -> D4 (through 1K)
    Relay IN -> D5
    SIM800L TXD -> D8   (Nano receives)
    SIM800L RXD <- D9   (through 1K/2K divider)
    SIM800L RST -> D10  (direct, we only pull it low)
    LCD SDA -> A4, SCL -> A5
    SIM800L power: 4.0V from LM2596 + 1000uF cap, common GND
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <SoftwareSerial.h>
#include <DHT.h>

// ================= USER SETTINGS =================
#define APN      "internet"              // your SIM's APN (Jio: jionet, Airtel: airtelgprs.com, Vi: www)
#define API_KEY  "YOUR_WRITE_API_KEY"    // ThingSpeak channel Write API key
#define PHONE    "+91XXXXXXXXXX"         // number that receives alerts

const float TEMP_MAX = 8.0;              // alert above this (C)
const float TEMP_MIN = 0.0;              // alert below this (C)
const float HUM_MAX  = 80.0;             // alert above this (%)
const float COMP_ON_TEMP  = 5.0;         // compressor ON at/above
const float COMP_OFF_TEMP = 3.0;         // compressor OFF at/below

const unsigned long COMP_MIN_OFF_MS  = 180000UL; // protect compressor: wait 3 min before restart
const unsigned long UPLOAD_MS        = 30000UL;  // ThingSpeak needs >= 15 s between updates
const unsigned long MAINS_TIMEOUT_MS = 3000UL;   // no mains seen for this long = power failure

#define MAINS_PRESENT_LEVEL HIGH   // pin level when mains is present (change if your module is opposite)
#define RELAY_ON  LOW              // most blue relay modules are active LOW. TEST WITHOUT LOAD FIRST.
#define RELAY_OFF HIGH
#define LCD_ADDR  0x27             // try 0x3F if the LCD stays blank
// =================================================

// Pins
const byte PIN_DHT = 2, PIN_AC = 3, PIN_BUZZER = 4, PIN_RELAY = 5;
const byte SIM_RX_PIN = 8, SIM_TX_PIN = 9, SIM_RST = 10;

DHT dht(PIN_DHT, DHT22);
LiquidCrystal_I2C lcd(LCD_ADDR, 16, 2);
SoftwareSerial sim(SIM_RX_PIN, SIM_TX_PIN);

float temp = 0, hum = 0;
bool dhtOk = false, powerOk = true, comp = false;
bool aTH = false, aTL = false, aHH = false, aPF = false;   // active alarm flags
byte failCount = 0;
unsigned long lastMains = 0, tDht = 0, tUp = 0, lastCompOff = 0;

// ---------- mains sensing ----------
void sampleMains() {
  if (digitalRead(PIN_AC) == MAINS_PRESENT_LEVEL) lastMains = millis();
}

// ---------- SIM800L helpers ----------
// Wait until 'target' appears in the modem reply (or timeout)
bool waitFor(const char* target, unsigned long ms) {
  char buf[48];
  byte n = 0;
  buf[0] = 0;
  unsigned long t = millis();
  while (millis() - t < ms) {
    sampleMains();                       // keep watching power during slow AT commands
    while (sim.available()) {
      char c = sim.read();
      if (n < 47) { buf[n++] = c; }
      else { memmove(buf, buf + 1, 46); buf[46] = c; }
      buf[n] = 0;
      if (strstr(buf, target)) return true;
    }
  }
  return false;
}

bool sendCmd(const __FlashStringHelper* cmd, const char* ok, unsigned long ms) {
  while (sim.available()) sim.read();
  sim.println(cmd);
  return waitFor(ok, ms);
}

void simInit() {
  sim.begin(9600);
  delay(3000);
  for (byte i = 0; i < 10; i++) if (sendCmd(F("AT"), "OK", 1000)) break;
  sendCmd(F("ATE0"), "OK", 1000);          // echo off
  sendCmd(F("AT+CMGF=1"), "OK", 1000);     // SMS text mode
  for (byte i = 0; i < 30; i++) {          // wait for network registration
    if (sendCmd(F("AT+CREG?"), ",1", 1000) || sendCmd(F("AT+CREG?"), ",5", 1000)) break;
    delay(1000);
  }
}

void simReset() {
  pinMode(SIM_RST, OUTPUT);
  digitalWrite(SIM_RST, LOW);
  delay(200);
  pinMode(SIM_RST, INPUT);                 // release (high-Z), safe for 2.8V logic
  delay(6000);
  simInit();
}

void sendSMS(const __FlashStringHelper* head) {
  while (sim.available()) sim.read();
  sim.print(F("AT+CMGS=\""));
  sim.print(F(PHONE));
  sim.println('"');
  if (!waitFor(">", 5000)) return;
  sim.print(head);
  sim.print(F(" Temp:"));
  sim.print(temp, 1);
  sim.print(F("C Hum:"));
  sim.print(hum, 0);
  sim.print('%');
  sim.write(26);                           // Ctrl+Z sends the message
  waitFor("OK", 15000);
}

bool gprsOpen() {
  sendCmd(F("AT+SAPBR=3,1,\"Contype\",\"GPRS\""), "OK", 2000);
  while (sim.available()) sim.read();
  sim.print(F("AT+SAPBR=3,1,\"APN\",\""));
  sim.print(F(APN));
  sim.println('"');
  waitFor("OK", 2000);
  sendCmd(F("AT+SAPBR=1,1"), "OK", 20000);          // may say ERROR if already open (fine)
  return sendCmd(F("AT+SAPBR=2,1"), "1,1,", 5000);  // 1,1 = connected
}

bool uploadData() {
  if (!gprsOpen()) return false;
  sendCmd(F("AT+HTTPTERM"), "OK", 1000);            // clean any old session
  if (!sendCmd(F("AT+HTTPINIT"), "OK", 3000)) return false;
  sendCmd(F("AT+HTTPPARA=\"CID\",1"), "OK", 1000);
  while (sim.available()) sim.read();
  sim.print(F("AT+HTTPPARA=\"URL\",\"http://api.thingspeak.com/update?api_key="));
  sim.print(F(API_KEY));
  sim.print(F("&field1="));
  sim.print(temp, 1);
  sim.print(F("&field2="));
  sim.print(hum, 0);
  sim.print(F("&field3="));
  sim.print(powerOk ? 1 : 0);
  sim.println('"');
  bool ok = waitFor("OK", 2000);
  if (ok) ok = sendCmd(F("AT+HTTPACTION=0"), "0,200", 20000);   // HTTP 200 = accepted
  sendCmd(F("AT+HTTPTERM"), "OK", 2000);
  return ok;
}

// ---------- alarms ----------
void checkAlarm(bool now, bool &flag, const __FlashStringHelper* alertMsg, const __FlashStringHelper* okMsg) {
  if (now && !flag) { flag = true;  sendSMS(alertMsg); }
  else if (!now && flag) { flag = false; sendSMS(okMsg); }
}

void checkAlarms() {
  checkAlarm(!powerOk, aPF, F("ALERT: POWER FAILURE."), F("Power restored."));
  if (!dhtOk) return;
  checkAlarm(temp > TEMP_MAX, aTH, F("ALERT: Temperature HIGH."), F("Temperature back to normal."));
  checkAlarm(temp < TEMP_MIN, aTL, F("ALERT: Temperature LOW."),  F("Temperature back to normal."));
  checkAlarm(hum  > HUM_MAX,  aHH, F("ALERT: Humidity HIGH."),    F("Humidity back to normal."));
}

// ---------- compressor ----------
void controlCompressor() {
  unsigned long now = millis();
  if (!powerOk) {
    if (comp) lastCompOff = now;
    comp = false;
  } else if (dhtOk) {
    if (comp && temp <= COMP_OFF_TEMP) { comp = false; lastCompOff = now; }
    else if (!comp && temp >= COMP_ON_TEMP && (now - lastCompOff >= COMP_MIN_OFF_MS)) comp = true;
  }
  digitalWrite(PIN_RELAY, comp ? RELAY_ON : RELAY_OFF);
}

// ---------- LCD ----------
void updateLcd() {
  char tb[8], line[20];
  lcd.setCursor(0, 0);
  if (dhtOk) {
    dtostrf(temp, 1, 1, tb);
    snprintf(line, sizeof(line), "T:%sC H:%d%%", tb, (int)(hum + 0.5));
    lcd.print(line);
    for (byte i = strlen(line); i < 16; i++) lcd.print(' ');
  } else {
    lcd.print(F("DHT22 ERROR     "));
  }
  lcd.setCursor(0, 1);
  if (!powerOk)    lcd.print(F("POWER FAIL!     "));
  else if (aTH)    lcd.print(F("TEMP HIGH!      "));
  else if (aTL)    lcd.print(F("TEMP LOW!       "));
  else if (aHH)    lcd.print(F("HUMIDITY HIGH!  "));
  else if (comp)   lcd.print(F("OK Comp:ON      "));
  else             lcd.print(F("OK Comp:OFF     "));
}

// ---------- setup / loop ----------
void setup() {
  pinMode(PIN_AC, INPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_RELAY, OUTPUT);
  digitalWrite(PIN_RELAY, RELAY_OFF);
  pinMode(SIM_RST, INPUT);
  lastMains = millis();

  lcd.init();
  lcd.backlight();
  lcd.print(F("Cold Storage"));
  lcd.setCursor(0, 1);
  lcd.print(F("Starting GSM..."));

  dht.begin();
  simInit();
  lcd.clear();
  tUp = millis() - UPLOAD_MS;              // upload right after first reading
}

void loop() {
  sampleMains();
  unsigned long now = millis();
  powerOk = (now - lastMains) < MAINS_TIMEOUT_MS;

  if (now - tDht >= 2000) {                // read sensors every 2 s
    tDht = now;
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    dhtOk = !(isnan(t) || isnan(h));
    if (dhtOk) { temp = t; hum = h; }
    controlCompressor();
    updateLcd();
    checkAlarms();                         // may block a few seconds while SMS sends
  }

  bool alarm = aTH || aTL || aHH || aPF;
  digitalWrite(PIN_BUZZER, alarm ? ((millis() / 500) % 2) : LOW);   // beeps when alarm active

  if (dhtOk && now - tUp >= UPLOAD_MS) {   // dashboard upload
    tUp = now;
    if (uploadData()) failCount = 0;
    else if (++failCount >= 3) { failCount = 0; simReset(); }       // recover a stuck modem
  }
}
